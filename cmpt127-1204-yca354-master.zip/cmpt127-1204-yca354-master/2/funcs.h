// funcs.h

int max( int int1, int int2);
int min( int int1, int int2);